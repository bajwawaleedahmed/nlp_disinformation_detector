import json
import joblib
import pandas as pd
from pathlib import Path
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split

# Paths
features_path = Path("/home/chief/PycharmProjects/nlp_disinformation_detector/data/stage2_features_final.json")
model_path = Path("/home/chief/PycharmProjects/nlp_disinformation_detector/src/models/stage2_logreg_model.pkl")

# Load features
with features_path.open("r", encoding="utf-8") as f:
    features = json.load(f)

df = pd.DataFrame(features)
df["label"] = df["label"].map({"true": 1, "false": 0})

# Split
X = df.drop(columns=["index", "label"])
y = df["label"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# Load model + scaler
bundle = joblib.load(model_path)
model = bundle["model"]
scaler = bundle["scaler"]

# Scale test data
X_test_scaled = scaler.transform(X_test)

# Predict and evaluate
y_pred = model.predict(X_test_scaled)

print("✅ Classification Report:")
print(classification_report(y_test, y_pred, target_names=["false", "true"]))
print("✅ Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
