import json
import spacy
from textblob import TextBlob
import textstat
from tqdm import tqdm
from pathlib import Path
from collections import Counter

nlp = spacy.load("en_core_web_sm")

input_path = Path("/home/chief/PycharmProjects/nlp_disinformation_detector/data/stage2_articles_with_kb_features.json")
output_path = Path("/home/chief/PycharmProjects/nlp_disinformation_detector/data/stage2_features_final.json")

def extract_features(article):
    text = article["text"]
    label = article["label"]

    doc = nlp(text)
    pos_counts = Counter([token.pos_ for token in doc])
    total_tokens = sum(pos_counts.values())

    pos_features = {
        "noun_ratio": pos_counts["NOUN"] / total_tokens if total_tokens else 0,
        "verb_ratio": pos_counts["VERB"] / total_tokens if total_tokens else 0,
        "adj_ratio": pos_counts["ADJ"] / total_tokens if total_tokens else 0,
        "adv_ratio": pos_counts["ADV"] / total_tokens if total_tokens else 0,
    }

    entity_counts = Counter([ent.label_ for ent in doc.ents])
    ner_features = {
        "num_ORG": entity_counts["ORG"],
        "num_GPE": entity_counts["GPE"],
        "num_PERSON": entity_counts["PERSON"],
        "num_DATE": entity_counts["DATE"]
    }

    blob = TextBlob(text)
    sentiment = {
        "polarity": blob.sentiment.polarity,
        "subjectivity": blob.sentiment.subjectivity
    }

    readability = {
        "flesch_reading_ease": textstat.flesch_reading_ease(text),
        "avg_sentence_length": textstat.words_per_sentence(text),
        "word_count": textstat.lexicon_count(text)
    }

    kb_features = {
        "mentions_known_entity": article.get("mentions_known_entity", 0),
        "matches_known_fact": article.get("matches_known_fact", 0)
    }

    return {
        "index": article["index"],
        **pos_features,
        **ner_features,
        **sentiment,
        **readability,
        **kb_features,
        "label": label
    }

# Load and process
with input_path.open("r", encoding="utf-8") as infile:
    articles = json.load(infile)

features = [extract_features(article) for article in tqdm(articles)]

with output_path.open("w", encoding="utf-8") as outfile:
    json.dump(features, outfile, indent=2)

print(f"✅ Final features with KB saved to {output_path}")
